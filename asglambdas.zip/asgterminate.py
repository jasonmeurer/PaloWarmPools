"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import boto3
from botocore.config import Config
import logging
import json
import http.client
import xml.etree.ElementTree as et
import time
from urllib.parse import urlparse
import urllib.parse
from contextlib import closing
import ssl
import decimal
import uuid
import sys
import urllib
import hashlib
import base64
from boto3.dynamodb.conditions import Key, Attr
from time import *
import os
import time
import re

s3 = boto3.client('s3')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client

logger = logging.getLogger()
logger.setLevel(logging.INFO)
logger.info("Terminate:AWS DATA PATH before: ")
logger.info(os.environ.get('AWS_DATA_PATH', ''))

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

LIFECYCLE_KEY = "LifecycleHookName"
ASG_KEY = "AutoScalingGroupName"
EC2_KEY = "EC2InstanceId"
DOCUMENT_NAME = "ASGLogBackup"
RESPONSE_DOCUMENT_KEY = "DocumentIdentifiers"


def lambda_handler(event, context):
    logger.info("Terminate:full event")
    logger.info(json.dumps(event))
    message = event['detail']
    logger.info("Terminate:message var")
    logger.info(json.dumps(message))
    instanceId = message['EC2InstanceId']
    logger.info("Terminate:instanceID var: %s", instanceId)
    metadata = message['NotificationMetadata']

    fwApiKey=metadata['KeyPANWFirewall']
    csplicensekey=metadata['csplicensekey']
    s3bucketvar=metadata['s3bucket']
    KeyPANWPanorama=metadata['KeyPANWPanorama']
    logger.info("Terminate:fwApiKey var: %s", fwApiKey)
    


    try:
        logger.info("Terminate:entering Try section of handler ")
        logger.info(json.dumps(event))    
    except Exception as e:
        logging.error("Error: %s", str(e))


    ## Get Firewall IP address
    logger.info("Terminate:Client IP address")
    instance = ec2.Instance(instanceId)
    logger.info("Terminate:full instance var: %s", instance)
    gwMgmtIp = instance.network_interfaces[1].private_ip_address
    logger.info("Terminate:IP addresss eth0: %s", gwMgmtIp)


    ### Get Panorama IP Address
    try:
        cmd_get_panorama = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=config&action=get&xpath=/config/devices/entry[@name='localhost.localdomain']/deviceconfig/system/panorama&key=" + fwApiKey)
        #cmd_get_panorama = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><panorama-status></panorama-status></show>&key=" + fwApiKey)
        logger.info("Terminate:output of get panorama %s", cmd_get_panorama) 
        urlcall_get_panorama = urllib.request.urlopen(cmd_get_panorama, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen panorama %s", urlcall_get_panorama) 
        response_get_panorama = urlcall_get_panorama.read().decode('utf-8')
        logger.info("Terminate:[RESPONSE]: %s", response_get_panorama) 
        resp_get_panorama = et.fromstring(response_get_panorama) 
        logger.info("text before panorama fine")
        logger.info("Terminate:[Panorama et root]: %s::%s", resp_get_panorama.tag, resp_get_panorama.attrib) 
        panoramaIPelement = resp_get_panorama.findall(".//panorama-server")
        panoramaIP = panoramaIPelement[0].text
        logger.info("Terminate:[Panorama IP]: %s", panoramaIP) 
    except:
        logging.error('Terminate: Get Panorama failed')


    ## Get Firewall Serial number and Host name
    try:
        cmd_get_fw_serial = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><system><info/></system></show>&key=" + fwApiKey)
        #cmd_get_fw_serial = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<show><fw_serial-status></fw_serial-status></show>&key=" + fwApiKey)
        logger.info("Terminate:output of get serial %s", cmd_get_fw_serial) 
        urlcall_get_fw_serial = urllib.request.urlopen(cmd_get_fw_serial, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen fw_serial %s", urlcall_get_fw_serial) 
        response_get_fw_serial = urlcall_get_fw_serial.read().decode('utf-8')
        logger.info("Terminate:[RESPONSE]: %s", response_get_fw_serial) 
        resp_get_fw_serial = et.fromstring(response_get_fw_serial) 
        logger.info("text before fw_serial fine")
        logger.info("Terminate:[fw_serial et root]: %s::%s", resp_get_fw_serial.tag, resp_get_fw_serial.attrib)         
        fw_serialelement = resp_get_fw_serial.findall(".//serial")
        fw_serial = fw_serialelement[0].text
        fw_hostnameelement = resp_get_fw_serial.findall(".//hostname")
        fw_hostname = fw_hostnameelement[0].text
        logger.info("Terminate:[fw_serial IP]: %s", fw_serial) 
        logger.info("Terminate:[fw_hostname IP]: %s", fw_hostname) 
    except:
        logging.error('Terminate: Get fw_serial failed')       


    ## Get DG and TS name THIS ASSUMES init-cfg.txt in bootstrap
    initkey = "config/init-cfg.txt"    
    key = urllib.parse.unquote_plus(initkey)    
    try:
        response = s3.get_object(Bucket=s3bucketvar, Key=key)
        logger.info("CONTENT TYPE: " + response['ContentType'])
        initcfgcontents=response['Body'].read().decode('utf-8')
        logger.info("Contents var: %s", initcfgcontents)
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist.'.format(key, s3bucketvar))
    s3dict = get_values_from_init_cfg(initcfgcontents)
    logger.info('Panorama: Init CFG bootstrap file Panorama settings is as follows: ')
    logger.info(s3dict)
    PanoramaDG=s3dict['dgname']
    PanoramaTPL=s3dict['tplname']
    logger.info("Terminate: DG: %s, Temlate: %s", PanoramaDG, PanoramaTPL) 


    # remove from DG
    try:
        cmd_remove_dg = urllib.request.Request("https://" + panoramaIP + "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='" + PanoramaDG + "']/devices/entry[@name='" + fw_serial + "']&key=" + KeyPANWPanorama)
        logger.info("Terminate:output of remove from DG %s", cmd_remove_dg) 
        urlcall_remove_dg = urllib.request.urlopen(cmd_remove_dg, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen fw_serial for DG %s", urlcall_remove_dg) 
        response_remove_dg = urlcall_remove_dg.read().decode('utf-8')
        logger.info("Terminate:[Remove from DG]: %s", response_remove_dg) 
    except: 
        logging.error('Terminate: remove DG failed')   


    # Remove from TS
    try:
        cmd_remove_ts = urllib.request.Request("https://" + panoramaIP + "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='" + PanoramaTPL + "']/devices/entry[@name='" + fw_serial + "']&key=" + KeyPANWPanorama)
        logger.info("Terminate:output of remove from DG %s", cmd_remove_ts) 
        urlcall_remove_ts = urllib.request.urlopen(cmd_remove_ts, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen fw_serial for TS %s", urlcall_remove_ts) 
        response_remove_ts = urlcall_remove_ts.read().decode('utf-8')
        logger.info("Terminate:[Remove from TS]: %s", response_remove_ts) 
    except: 
        logging.error('Terminate: remove TS failed')    


    # Remove from Managed Devices
    try:
        cmd_remove_mgddev = urllib.request.Request("https://" + panoramaIP + "/api/?type=config&action=delete&xpath=/config/mgt-config/devices/entry[@name='" + fw_serial + "']&key=" + KeyPANWPanorama)
        logger.info("Terminate:output of remove from MgdDev %s", cmd_remove_mgddev) 
        urlcall_remove_mgddev = urllib.request.urlopen(cmd_remove_mgddev, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen fw_serial for MgdDev %s", urlcall_remove_mgddev) 
        response_remove_mgddev = urlcall_remove_mgddev.read().decode('utf-8')
        logger.info("Terminate:[Removed from MgdDev]: %s", response_remove_mgddev) 
    except: 
        logging.error('Terminate: remove MgdDev failed')  


    # Panorama Commit        
    try:
        cmd_panorama_commit = urllib.request.Request("https://" + panoramaIP + "/api/?type=commit&cmd=<commit></commit>&key="+ KeyPANWPanorama)
        logger.info("Terminate:output of Panorama Commit %s", cmd_panorama_commit) 
        urlcall_panorama_commit = urllib.request.urlopen(cmd_panorama_commit, data=None, context=ctx, timeout=5)
        logger.info("Terminate:output of urlopen Panorama Commit %s", urlcall_panorama_commit) 
        response_panorama_commit = urlcall_panorama_commit.read().decode('utf-8')
        logger.info("Terminate:[Panorama Commit Result]: %s", response_panorama_commit) 
    except: 
        logging.error('Terminate: Panorama Commit failed')    


    ## Dereg Firewall License
    byol_code = "6njl1pau431dv1qxipg63mvah"
    try:
        instance_properties = ec2_client.describe_instances(
            InstanceIds=[instanceId],
        )
        ami_id = instance_properties['Reservations'][0]['Instances'][0]['ImageId']
        ami_info = ec2_client.describe_images(
            ImageIds=[ami_id])
        logger.info('describe_instances:response: %s',instance_properties)
        logger.info('describe_images:response: %s',ami_info)
        product_codes = ami_info['Images'][0]['ProductCodes']
    except Exception as e:
        instance_properties = None
        product_codes = []
        logger.error("Exception occurred while retrieving instance ID %s properties: %s",instanceId, e)
        
    if product_codes:
        logger.info('productCodes: %s', product_codes)
        for code in product_codes:
            product_code_id = code.get("ProductCodeId", None)
            if product_code_id in byol_code:
                logger.info("matched product codes")
                try:
                    cmd_set_csp_api = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&cmd=<request><license><api-key><set><key>" + csplicensekey + "</key></set></api-key></license></request>&key=" + fwApiKey)
                    logger.info("Terminate:output set api key %s", cmd_set_csp_api) 
                    urlcall_remove_ts = urllib.request.urlopen(cmd_set_csp_api, data=None, context=ctx, timeout=20)
                    logger.info("Terminate:output of urlopen set api key %s", urlcall_remove_ts) 
                    response_remove_ts = urlcall_remove_ts.read().decode('utf-8')
                    logger.info("Terminate:[Set API Key]: %s", response_remove_ts) 

                    cmd_fw_dereg = urllib.request.Request("https://" + gwMgmtIp + "/api/?type=op&&cmd=<request><license><deactivate><VM-Capacity><mode>auto</mode></VM-Capacity></deactivate></license></request>&key=" + fwApiKey)
                    logger.info("Terminate:output dereg fw %s", cmd_fw_dereg) 
                    urlcall_fw_dereg = urllib.request.urlopen(cmd_fw_dereg, data=None, context=ctx, timeout=60)
                    logger.info("Terminate:output of dereg fw %s", urlcall_fw_dereg) 
                    response_fw_dereg = urlcall_fw_dereg.read().decode('utf-8')
                    logger.info("Terminate:[dereg fw ]: %s", response_fw_dereg) 
                except urllib.error.HTTPError as e:
                    logger.info('HTTPError: ', e.code)
                except urllib.error.URLError as e:
                    logger.info('URL Error: ', e.reason)
                except http.client.RemoteDisconnected as e:
                    logger.info('Disconnect expected: %s', e)
                except Exception as e:
                    logger.info("Exception error in dereg block: %s", e)    
                except: 
                    logging.error('Terminate: set api key failed')                 
                break
            else:
                logging.error('Terminate: Paygo product code not found, assume Paygo') 
    else:
        # No productCodes returned; assume PayGo
        logger.warning('No productCodes retrieved; assume Paygo.')
        
 
    logger.info("Terminate:logging after after URL Call")          


    ## Release Lifecycle Hook
    asgClient = boto3.client('autoscaling')
    lifeCycleHook = message['LifecycleHookName']
    autoScalingGroup = message['AutoScalingGroupName']
    logger.info("Terminate:logging before response")  
    actionResult = "CONTINUE"
    response = asgClient.complete_lifecycle_action(
        LifecycleHookName = lifeCycleHook,
        AutoScalingGroupName = autoScalingGroup,
        LifecycleActionResult = actionResult,
        InstanceId = instanceId
    )
    logger.info("Terminate:logging vars after response")  
    logger.info(response)  
    logger.info(asgClient)  
    logger.info(lifeCycleHook)  
    logger.info(autoScalingGroup)  


def get_values_from_init_cfg(contents):
    """
    Retrieve the keys from the init-cfg file
    :param contents:
    :return: dict
    """
    d = {'panorama-server': "", 'tplname': "", 'dgname': "", 'hostname': ""}
    if contents is None:
        return d

    contents=contents.replace('\n', '::')
    list=contents.split("::")
    for i in list:
        if i == "":
            continue

        s=i.split("=")
        if s[0] != "" and s[0] == "panorama-server" and s[1] != "":
            d['panorama-server']=s[1]
        elif s[0] != "" and s[0] == "tplname" and s[1] != "":
            d['tplname']=s[1]
        elif s[0] != "" and s[0] == "dgname" and s[1] != "":
            d['dgname']=s[1]
        elif s[0] != "" and s[0] == "hostname" and s[1] != "":
            d['hostname']=s[1]

    return d    