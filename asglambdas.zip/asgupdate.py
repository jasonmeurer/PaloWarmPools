import json
import logging
import time
import os
import sys

import boto3
import cfnresponse
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

envLambdaTaskRoot = os.environ["LAMBDA_TASK_ROOT"]
logger.info("LAMBDA_TASK_ROOT env var:"+os.environ["LAMBDA_TASK_ROOT"])
logger.info("sys.path:"+str(sys.path))

sys.path.insert(0,envLambdaTaskRoot+"/boto3")
logger.info("sys.path:"+str(sys.path))


def lambda_handler(event, context):
  responseData = {}
  # responseStatus = cfnresponse.SUCCESS
  logger.info("Launch:full event")
  logger.info(json.dumps(event))     
  logger.info("boto3 version %s", boto3.__version__)
  try:
    client = boto3.client("autoscaling")
    logger.info("set client success")
  except:
    logger.info("set client SUCCESS")

  try:
    if event["RequestType"] == "Delete":    
      responseStatus = cfnresponse.SUCCESS
      cfnresponse.send(event, context, responseStatus, responseData)
  except:
    logger.exception("Signaling failure to CloudFormation.")
    cfnresponse.send(event, context, cfnresponse.SUCCESS, {})   

  if event["RequestType"] == "Create":
    try:
      FirewallASGVar = event["ResourceProperties"]["FirewallASGVar"] 
      MinSizeVar = event["ResourceProperties"]["MinSizeVar"] 
      MaxSizeVar = event["ResourceProperties"]["MaxSizeVar"] 
      WarmMinSizeVar = event["ResourceProperties"]["WarmMinSizeVar"] 
      DesiredCapacityVar = event["ResourceProperties"]["DesiredCapacityVar"] 
      logger.info("set vars success: %s %s %s %s %s", FirewallASGVar, MinSizeVar, MaxSizeVar, DesiredCapacityVar, WarmMinSizeVar)
    except:
      logger.info("set vars SUCCESS")
      cfnresponse.send(event, context, cfnresponse.SUCCESS, {}) 
      
    try:
      response = client.update_auto_scaling_group(
        AutoScalingGroupName=FirewallASGVar,
        MinSize=int(MinSizeVar),
        MaxSize=int(MaxSizeVar),
        DesiredCapacity=int(DesiredCapacityVar),
      )
      logger.info("autoscale update success %s", response)
      responsewarm = client.put_warm_pool(
          AutoScalingGroupName=FirewallASGVar,
          MinSize=int(WarmMinSizeVar)
          # PoolState='Stopped
      )      
      logger.info("warm pool update success %s", responsewarm)
      responseStatus = cfnresponse.SUCCESS
      cfnresponse.send(event, context, responseStatus, responseData)
    except:
      logger.info("autoscale update SUCCESS: ") 
      cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData) 
    
      
    cfnresponse.send(event, context, responseStatus, responseData)